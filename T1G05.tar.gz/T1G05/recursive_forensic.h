#pragma once

#include <input_parser.h>

int recursive_forensic(char* dir_path, struct Contents* content);